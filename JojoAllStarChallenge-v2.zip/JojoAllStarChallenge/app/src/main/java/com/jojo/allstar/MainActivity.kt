package com.jojo.allstar

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.system.Os
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File

class MainActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var surface: SurfaceView
    private lateinit var overlay: OverlayView
    private lateinit var romsDir: File
    private lateinit var masterRom: File
    private var emuThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var paused = true
    @Volatile private var surfaceReady = false
    @Volatile private var gameReady = false
    private var track: AudioTrack? = null
    private var starting = false
    @Volatile private var pendingSave = false
    @Volatile private var pendingLoad = false
    @Volatile private var macro: IntArray? = null
    private var macroIdx = 0
    private val stateFile get() = File(File(filesDir, "states").apply { mkdirs() }, "slot1.state")

    private fun mark(s: String) {
        try { File(filesDir, "last.txt").appendText(s + "\n") } catch (_: Exception) {}
    }

    // nomes possíveis do set no FBNeo (o core identifica o jogo pelo nome do zip)
    private val names = listOf("jojobaner2")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        val lastF = File(filesDir, "last.txt")
        val prevLog = try { if (lastF.exists()) lastF.readText() else "" } catch (_: Exception) { "" }
        try { lastF.delete() } catch (_: Exception) {}
        val oldH = Thread.getDefaultUncaughtExceptionHandler()
        Thread.setDefaultUncaughtExceptionHandler { t, e ->
            mark("EXCECAO: " + e.toString() + " | " + e.stackTrace.take(6).joinToString(" < "))
            oldH?.uncaughtException(t, e)
        }
        if (prevLog.isNotBlank() && !prevLog.contains("FIM")) {
            AlertDialog.Builder(this).setTitle("O app fechou da última vez")
                .setMessage(prevLog.takeLast(900)).setPositiveButton("OK", null).show()
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        romsDir = File(filesDir, "roms").apply { mkdirs() }
        masterRom = File(romsDir, "rom.zip")
        surface = SurfaceView(this)
        surface.holder.addCallback(this)
        overlay = OverlayView(this)
        overlay.onOption = { runOnUiThread { showMenu() } }
        overlay.onExit = { runOnUiThread { confirmExit() } }
        overlay.onEditDone = { runOnUiThread { paused = false; hideBars() } }
        val root = FrameLayout(this)
        root.addView(surface, FrameLayout.LayoutParams(-1, -1))
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        hideBars()
    }

    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }

    override fun surfaceCreated(h: SurfaceHolder) {
        Native.setSurface(h.surface); surfaceReady = true
        if (!gameReady && !starting) {
            if (masterRom.exists() && masterRom.length() > 1_000_000) startEmu() else askRom(true)
        } else paused = false
    }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { surfaceReady = false; paused = true; Native.setSurface(null) }

    override fun onPause() { super.onPause(); paused = true; overlay.clearInput(); track?.pause() }
    override fun onResume() { super.onResume(); if (gameReady && surfaceReady) { paused = false; track?.play() } }

    override fun onDestroy() {
        if (isFinishing) mark("FIM")
        running = false
        try { emuThread?.join(1500) } catch (_: Exception) {}
        if (gameReady) { Native.unload(); gameReady = false }
        track?.release()
        super.onDestroy()
    }

    // ---------- importar ROM (só na primeira vez; depois fica guardada no app) ----------
    private fun askRom(first: Boolean) {
        AlertDialog.Builder(this).setTitle("ROM do jogo")
            .setMessage(if (first) "Escolha o arquivo .zip da ROM. Isso só é preciso uma vez: o app guarda uma cópia e você pode apagar o arquivo dos Downloads." else "Escolha o novo arquivo .zip da ROM.")
            .setCancelable(false)
            .setPositiveButton("Escolher") { _, _ ->
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                startActivityForResult(i, 42)
            }
            .setNegativeButton("Sair") { _, _ -> finish() }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req == 43) {
            val u: Uri? = data?.data
            if (res == RESULT_OK && u != null) importNv(u) else paused = false
            return
        }
        if (req != 42) return
        val uri: Uri? = data?.data
        if (res != RESULT_OK || uri == null) { askRom(!masterRom.exists()); return }
        Toast.makeText(this, "Copiando ROM...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val tmp = File(romsDir, "rom.tmp")
                contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                val conv = convertIfNeeded(tmp)
                if (conv != null) { tmp.delete(); conv.renameTo(tmp) }
                romsDir.listFiles()?.filter { it.name != "rom.tmp" }?.forEach { it.delete() }
                getSharedPreferences("p", MODE_PRIVATE).edit().clear().apply()
                tmp.renameTo(masterRom)
                gameReady = false
                runOnUiThread { if (surfaceReady) startEmu() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Erro ao copiar: ${e.message}", Toast.LENGTH_LONG).show(); askRom(true) }
            }
        }.start()
    }

    // ---------- converter ROM no formato "flash" (10,20,30...) para os chips que o FBNeo espera ----------
    private fun convertIfNeeded(src: File): File? {
        val zf = try { java.util.zip.ZipFile(src) } catch (e: Exception) { return null }
        zf.use { z ->
            if (z.getEntry("10") == null || z.getEntry("20") == null) return null
            runOnUiThread { Toast.makeText(this, "Convertendo ROM (pode demorar)...", Toast.LENGTH_LONG).show() }
            val out = File(romsDir, "conv.tmp")
            java.util.zip.ZipOutputStream(out.outputStream().buffered(1 shl 16)).use { zo ->
                fun put(name: String, data: ByteArray) {
                    val e = java.util.zip.ZipEntry(name)
                    e.method = java.util.zip.ZipEntry.STORED
                    e.size = data.size.toLong()
                    e.compressedSize = data.size.toLong()
                    val c = java.util.zip.CRC32()
                    c.update(data)
                    e.crc = c.value
                    zo.putNextEntry(e)
                    zo.write(data)
                    zo.closeEntry()
                }
                fun read(name: String): ByteArray = z.getInputStream(z.getEntry(name)).use { it.readBytes() }
                val bios = z.entries().toList().firstOrNull { it.name.endsWith(".29f400.u2") }
                if (bios != null) put(bios.name, read(bios.name))
                for ((simm, f) in listOf(1 to "10", 2 to "20")) {
                    val d = read(f)
                    val sz = d.size / 4
                    for (k in 0 until 4) {
                        val chip = ByteArray(sz)
                        var i = k
                        for (j in 0 until sz) { chip[j] = d[i]; i += 4 }
                        put("jojoba-simm$simm.$k", chip)
                    }
                }
                for ((simm, files) in listOf(3 to listOf("30", "31"), 4 to listOf("40", "41"), 5 to listOf("50", "51"))) {
                    for ((fi, f) in files.withIndex()) {
                        val d = read(f)
                        for (p in 0 until 2) for (c in 0 until 2) {
                            val chip = ByteArray(0x200000)
                            var idx = c * 0x400000 + p
                            for (n in 0 until 0x200000) { chip[n] = d[idx]; idx += 2 }
                            put("jojoba-simm$simm.${fi * 4 + 2 * c + p}", chip)
                        }
                    }
                }
            }
            return out
        }
    }

    private fun describeRom(): String = try {
        java.util.zip.ZipFile(masterRom).use { z ->
            "rom.zip ${masterRom.length()} bytes, ${z.size()} arquivos, ex: " + z.entries().toList().take(3).joinToString(",") { it.name }
        }
    } catch (e: Exception) { "rom.zip erro: ${e.message}" }

    // ---------- emulação ----------
    private fun linkName(n: String) {
        val f = File(romsDir, "$n.zip")
        if (f.exists()) return
        try { Os.symlink(masterRom.absolutePath, f.absolutePath) } catch (_: Exception) { masterRom.copyTo(f, true) }
    }

    private fun startEmu() {
        if (starting) return
        starting = true; running = false
        try { emuThread?.join(1500) } catch (_: Exception) {}
        running = true; paused = true
        emuThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
            val sys = File(filesDir, "system").apply { mkdirs() }
            val save = File(filesDir, "saves").apply { mkdirs(); File(this, "fbneo").mkdirs() }
            val core = File(applicationInfo.nativeLibraryDir, "libfbneo_libretro.so")
            Native.clearLog()
            mark(describeRom())
            mark("loadCore")
            if (!Native.loadCore(core.absolutePath, sys.absolutePath, save.absolutePath)) { fail("Não consegui carregar o core."); return@Thread }
            names.forEach { linkName(it) }
            mark("links ok")
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val order = names
            var ok = false
            val tried = StringBuilder()
            runOnUiThread { Toast.makeText(this, "Identificando a ROM (só na primeira vez)...", Toast.LENGTH_LONG).show() }
            val dummy = ShortArray(16384)
            for (n in order.distinct()) {
                if (!running) return@Thread
                mark("tentando $n")
                if (!Native.loadGame(File(romsDir, "$n.zip").absolutePath)) { tried.append("$n: recusado\n"); continue }
                mark("carregou $n")
                Native.detect(true)
                repeat(4) { Native.runFrame(dummy) }
                val score = Native.errScore()
                mark("score $n = $score")
                Native.detect(false)
                if (score < 0) { prefs.edit().putString("name", n).apply(); ok = true; break }
                tried.append("$n: tela de erro ($score)\n")
                mark("unload apos erro")
                Native.unload()
            }
            if (!ok) { fail("Nenhum nome de set funcionou com essa ROM.", tried.toString()); return@Thread }
            mark("pronto, iniciando loop")
            val rate = Native.sampleRate()
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(min * 3).setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
            track!!.play()
            gameReady = true; starting = false; paused = !surfaceReady
            val buf = ShortArray(16384)
            while (running) {
                if (paused) { Thread.sleep(30); continue }
                if (pendingSave) {
                    pendingSave = false
                    val ok = Native.saveState(stateFile.absolutePath)
                    runOnUiThread { Toast.makeText(this, if (ok) "Estado salvo" else "Falha ao salvar estado", Toast.LENGTH_SHORT).show() }
                }
                if (pendingLoad) {
                    pendingLoad = false
                    val ok = stateFile.exists() && Native.loadState(stateFile.absolutePath)
                    runOnUiThread { Toast.makeText(this, if (ok) "Estado carregado" else "Nenhum estado salvo", Toast.LENGTH_SHORT).show() }
                }
                val m = macro
                if (m != null) {
                    if (macroIdx < m.size) Native.setMacro(m[macroIdx++]) else { Native.setMacro(0); macro = null }
                }
                val t0 = System.nanoTime()
                val n = Native.runFrame(buf)
                if (n > 0) track!!.write(buf, 0, n * 2, AudioTrack.WRITE_BLOCKING)
                else { val dt = (System.nanoTime() - t0) / 1_000_000; if (dt < 16) Thread.sleep(16 - dt) }
            }
        }.also { it.start() }
    }

    private fun fail(msg: String, extra: String = "") {
        starting = false
        val log = extra + "\n" + Native.lastLog().takeLast(1000)
        runOnUiThread {
            AlertDialog.Builder(this).setTitle("Erro").setMessage("$msg\n\n$log").setCancelable(false)
                .setPositiveButton("Escolher outra ROM") { _, _ -> askRom(false) }
                .setNegativeButton("Sair") { _, _ -> finish() }.show()
        }
    }

    // ---------- menus ----------
    // Código dos personagens secretos: segurar START e apertar CIMA 3x com o cursor em cima do DIO ou do JOSEPH
    private fun secretMacro(): IntArray {
        val st = 1 shl OverlayView.START; val up = 1 shl OverlayView.UP
        val l = ArrayList<Int>()
        repeat(12) { l.add(st) }
        repeat(3) { repeat(5) { l.add(st or up) }; repeat(7) { l.add(st) } }
        repeat(12) { l.add(st) }
        l.add(0)
        return l.toIntArray()
    }

    private fun askNv() {
        val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
        startActivityForResult(i, 43)
    }

    private fun importNv(uri: Uri) {
        Thread {
            try {
                running = false
                try { emuThread?.join(2000) } catch (_: Exception) {}
                if (gameReady) { Native.unload(); gameReady = false }
                val data = contentResolver.openInputStream(uri)!!.use { it.readBytes() }
                val base = File(filesDir, "saves")
                for (d in listOf(base, File(base, "fbneo"))) {
                    d.mkdirs()
                    for (n in names) File(d, "$n.nv").writeBytes(data)
                }
                starting = false
                runOnUiThread { Toast.makeText(this, "Save importado", Toast.LENGTH_SHORT).show(); if (surfaceReady) startEmu() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show(); starting = false; if (surfaceReady) startEmu() }
            }
        }.start()
    }

    private fun exportNv() {
        try {
            val base = File(filesDir, "saves")
            val f = listOf(File(base, "${names[0]}.nv"), File(base, "fbneo/${names[0]}.nv")).firstOrNull { it.exists() }
            if (f == null) { Toast.makeText(this, "Ainda não existe save (saia do jogo uma vez)", Toast.LENGTH_LONG).show(); return }
            val out = File(getExternalFilesDir(null), "${names[0]}.nv")
            f.copyTo(out, true)
            Toast.makeText(this, "Salvo em: ${out.absolutePath}", Toast.LENGTH_LONG).show()
        } catch (e: Exception) { Toast.makeText(this, "Erro: ${e.message}", Toast.LENGTH_LONG).show() }
    }

    private fun showMenu() {
        paused = true; overlay.clearInput()
        AlertDialog.Builder(this).setTitle("Jojo's All Star Challenge")
            .setItems(arrayOf("Continuar", "Salvar estado", "Carregar estado", "Código secreto (Shadow DIO / Young Joseph)",
                "Importar save com secretos (.nv)", "Exportar save (.nv)", "Reiniciar jogo", "Editar botões", "Trocar ROM", "Sair")) { _, w ->
                when (w) {
                    1 -> { pendingSave = true; paused = false }
                    2 -> { pendingLoad = true; paused = false }
                    3 -> {
                        AlertDialog.Builder(this).setTitle("Código secreto")
                            .setMessage("Na tela de seleção de personagem, coloque o cursor em cima do DIO (para Shadow DIO) ou do JOSEPH (para Young Joseph) e toque em Executar. O app segura START e aperta CIMA 3 vezes sozinho. O desbloqueio fica gravado no save.")
                            .setPositiveButton("Executar") { _, _ -> macroIdx = 0; macro = secretMacro(); paused = false }
                            .setNegativeButton("Voltar") { _, _ -> paused = false }
                            .setOnCancelListener { paused = false }.show()
                    }
                    4 -> askNv()
                    5 -> { exportNv(); paused = false }
                    6 -> { Native.reset(); paused = false }
                    7 -> { paused = true; overlay.startEdit() }
                    8 -> { paused = true; askRom(false) }
                    9 -> finish()
                    else -> paused = false
                }
            }.setOnCancelListener { paused = false }.show()
    }

    private fun confirmExit() {
        paused = true; overlay.clearInput()
        AlertDialog.Builder(this).setMessage("Sair do jogo?")
            .setPositiveButton("Sair") { _, _ -> finish() }
            .setNegativeButton("Voltar") { _, _ -> paused = false }
            .setOnCancelListener { paused = false }.show()
    }
}
