
## Novidades
- Menu OPTION: **Salvar estado / Carregar estado** (1 slot, fica no app).
- **Código secreto**: com o cursor em cima do DIO ou do JOSEPH na seleção de personagem, o app faz START + CIMA x3 sozinho (Shadow DIO / Young Joseph).
- **Importar save (.nv)**: coloca um save já com tudo desbloqueado. **Exportar save (.nv)**: copia o seu para a pasta do app.
