package com.jojo.allstar

import android.content.Context
import android.graphics.*
import android.view.MotionEvent
import android.view.View

class OverlayView(c: Context) : View(c) {
    companion object {
        const val B = 0; const val Y = 1; const val SELECT = 2; const val START = 3
        const val UP = 4; const val DOWN = 5; const val LEFT = 6; const val RIGHT = 7
        const val A = 8; const val X = 9; const val L = 10; const val R = 11
        const val OPTION = 100; const val EXIT = 101
    }

    class Btn(val id: Int, val bmp: Bitmap, val oval: Boolean) {
        var cx = 0f; var cy = 0f; var w = 0f; var h = 0f; var down = false
        var dcx = 0f; var dcy = 0f; var dw = 0f; var dh = 0f; var sc = 1f
        val key get() = "b$id"
        fun hit(x: Float, y: Float): Boolean {
            val dx = (x - cx) / (w / 2f * 1.08f); val dy = (y - cy) / (h / 2f * 1.15f)
            return if (oval) dx * dx + dy * dy <= 1f else Math.abs(dx) <= 1f && Math.abs(dy) <= 1.1f
        }
    }

    var onOption: (() -> Unit)? = null
    var onExit: (() -> Unit)? = null
    var onEditDone: (() -> Unit)? = null
    var editMode = false

    private val prefs = context.getSharedPreferences("layout", Context.MODE_PRIVATE)
    private fun load(n: String): Bitmap = context.assets.open("$n.png").use { BitmapFactory.decodeStream(it) }
    private val analogBmp = load("analog")
    private val btns = listOf(
        Btn(L, load("L"), true), Btn(R, load("R"), true),
        Btn(Y, load("Y"), true), Btn(X, load("X"), true),
        Btn(B, load("B"), true), Btn(A, load("A"), true),
        Btn(EXIT, load("pill_exit"), false), Btn(SELECT, load("pill_coin"), false),
        Btn(OPTION, load("pill_option"), false), Btn(START, load("pill_start"), false)
    )
    private val paint = Paint(Paint.FILTER_BITMAP_FLAG or Paint.ANTI_ALIAS_FLAG)
    private val textPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { color = Color.WHITE; textAlign = Paint.Align.CENTER; isFakeBoldText = true }
    private val boxPaint = Paint(Paint.ANTI_ALIAS_FLAG)
    private val selPaint = Paint(Paint.ANTI_ALIAS_FLAG).apply { style = Paint.Style.STROKE; color = Color.YELLOW; strokeWidth = 5f }

    private var ax = 0f; private var ay = 0f; private var ar = 0f
    private var dax = 0f; private var day = 0f; private var dar = 0f; private var asc = 1f
    private var knobX = 0f; private var knobY = 0f
    private var analogPtr = -1

    private val toolbar = ArrayList<RectF>()
    private val toolbarLabels = listOf("−", "+", "Resetar", "Pronto")

    private val knobBmp: Bitmap by lazy {
        val s = analogBmp.width; val cc = s * 0.5f; val r = s * 0.225f
        val out = Bitmap.createBitmap((r * 2).toInt(), (r * 2).toInt(), Bitmap.Config.ARGB_8888)
        val cv = Canvas(out); val p = Paint(Paint.ANTI_ALIAS_FLAG)
        cv.drawCircle(r, r, r, p)
        p.xfermode = PorterDuffXfermode(PorterDuff.Mode.SRC_IN)
        cv.drawBitmap(analogBmp, -(cc - r), -(analogBmp.height * 0.5f - r), p)
        out
    }

    override fun onSizeChanged(w: Int, h: Int, ow: Int, oh: Int) {
        val H = h.toFloat(); val W = w.toFloat()
        val m = H * 0.05f
        // analógico menor (embaixo à esquerda)
        dar = H * 0.40f / 2f; dax = m * 1.6f + dar; day = H - m - dar
        // botões de ataque (embaixo à direita)
        val bw = H * 0.20f
        val rowH = bw * 0.70f
        val rightX = W - m * 1.4f - bw * 0.5f
        val colGap = bw * 1.0f
        val baseY = H - m - rowH * 0.5f
        for (i in 0..5) {
            val b = btns[i]; val col = i % 2; val row = i / 2
            val shift = when (row) { 0 -> bw * 0.08f; 1 -> -bw * 0.10f; else -> 0f }
            b.dw = bw; b.dh = bw * b.bmp.height / b.bmp.width
            b.dcx = rightX - (1 - col) * colGap + shift
            b.dcy = baseY - (2 - row) * rowH * 1.02f
        }
        val pw = H * 0.19f
        for (b in btns.drop(6)) { b.dw = pw; b.dh = pw * b.bmp.height / b.bmp.width }
        btns[6].dcx = m + pw / 2; btns[6].dcy = H * 0.20f
        btns[7].dcx = m + pw / 2; btns[7].dcy = H * 0.20f + pw * 0.5f
        btns[8].dcx = W - m - pw / 2; btns[8].dcy = H * 0.20f
        btns[9].dcx = W - m - pw / 2; btns[9].dcy = H * 0.20f + pw * 0.5f
        // barra do modo de edição
        toolbar.clear()
        val tw = H * 0.30f; val th = H * 0.11f; val gap = H * 0.02f
        val total = 4 * tw + 3 * gap; var x = (W - total) / 2f
        for (i in 0..3) { toolbar.add(RectF(x, H * 0.04f, x + tw, H * 0.04f + th)); x += tw + gap }
        textPaint.textSize = th * 0.5f
        applyLayout()
    }

    private fun applyLayout() {
        val W = width.toFloat(); val H = height.toFloat()
        for (b in btns) {
            val p = prefs.getString(b.key, null)?.split(",")
            if (p != null && p.size == 3) { b.cx = p[0].toFloat() * W; b.cy = p[1].toFloat() * H; b.sc = p[2].toFloat() }
            else { b.cx = b.dcx; b.cy = b.dcy; b.sc = 1f }
            b.w = b.dw * b.sc; b.h = b.dh * b.sc
        }
        val p = prefs.getString("analog", null)?.split(",")
        if (p != null && p.size == 3) { ax = p[0].toFloat() * W; ay = p[1].toFloat() * H; asc = p[2].toFloat() }
        else { ax = dax; ay = day; asc = 1f }
        ar = dar * asc
        knobX = ax; knobY = ay
    }

    private fun saveAll() {
        val W = width.toFloat(); val H = height.toFloat()
        val ed = prefs.edit()
        for (b in btns) ed.putString(b.key, "${b.cx / W},${b.cy / H},${b.sc}")
        ed.putString("analog", "${ax / W},${ay / H},$asc")
        ed.apply()
    }

    fun startEdit() { editMode = true; clearInput(); invalidate() }

    override fun onDraw(c: Canvas) {
        if (editMode) c.drawColor(Color.argb(110, 0, 0, 0))
        val ah = ar * analogBmp.height / analogBmp.width
        paint.alpha = 255
        c.drawBitmap(analogBmp, null, RectF(ax - ar, ay - ah, ax + ar, ay + ah), paint)
        val kr = ar * 0.45f
        c.drawBitmap(knobBmp, null, RectF(knobX - kr, knobY - kr, knobX + kr, knobY + kr), paint)
        for (b in btns) {
            paint.alpha = if (b.down) 255 else 205
            val sc = if (b.down) 0.93f else 1f
            val hw = b.w / 2 * sc; val hh = b.h / 2 * sc
            c.drawBitmap(b.bmp, null, RectF(b.cx - hw, b.cy - hh, b.cx + hw, b.cy + hh), paint)
        }
        paint.alpha = 255
        if (editMode) {
            if (selAnalog) c.drawCircle(ax, ay, ar * 1.02f, selPaint)
            selBtn?.let { c.drawRoundRect(RectF(it.cx - it.w / 2, it.cy - it.h / 2, it.cx + it.w / 2, it.cy + it.h / 2), 20f, 20f, selPaint) }
            for ((i, r) in toolbar.withIndex()) {
                boxPaint.color = if (i == 3) Color.rgb(30, 120, 50) else Color.rgb(60, 30, 100)
                c.drawRoundRect(r, 24f, 24f, boxPaint)
                c.drawText(toolbarLabels[i], r.centerX(), r.centerY() + textPaint.textSize * 0.35f, textPaint)
            }
            val hint = "Toque num botão, arraste para mover, use − + ou pince para o tamanho"
            val tp = Paint(textPaint).apply { textSize = height * 0.04f; isFakeBoldText = false }
            c.drawText(hint, width / 2f, height * 0.04f + height * 0.11f + height * 0.06f, tp)
        }
    }

    // ---------- modo de edição ----------
    private var selBtn: Btn? = null
    private var selAnalog = false
    private var dragDX = 0f; private var dragDY = 0f; private var dragOK = false
    private var pinchStart = 0f; private var pinchBase = 1f

    private fun curScale() = if (selAnalog) asc else selBtn?.sc ?: 1f
    private fun setScale(s: Float) {
        val v = s.coerceIn(0.4f, 2.2f)
        if (selAnalog) { asc = v; ar = dar * v; knobX = ax; knobY = ay }
        else selBtn?.let { it.sc = v; it.w = it.dw * v; it.h = it.dh * v }
    }

    private fun editTouch(e: MotionEvent): Boolean {
        when (e.actionMasked) {
            MotionEvent.ACTION_DOWN -> {
                val x = e.x; val y = e.y
                val t = toolbar.indexOfFirst { it.contains(x, y) }
                if (t >= 0) { toolbarAction(t); return true }
                selBtn = null; selAnalog = false
                if (Math.hypot((x - ax).toDouble(), (y - ay).toDouble()) <= ar) selAnalog = true
                for (b in btns.reversed()) if (b.hit(x, y)) { selBtn = b; selAnalog = false; break }
                dragOK = selAnalog || selBtn != null
                if (selAnalog) { dragDX = ax - x; dragDY = ay - y } else selBtn?.let { dragDX = it.cx - x; dragDY = it.cy - y }
                pinchStart = 0f
            }
            MotionEvent.ACTION_POINTER_DOWN -> { pinchStart = 0f; dragOK = false }
            MotionEvent.ACTION_MOVE -> {
                if (e.pointerCount >= 2 && (selAnalog || selBtn != null)) {
                    val d = Math.hypot((e.getX(0) - e.getX(1)).toDouble(), (e.getY(0) - e.getY(1)).toDouble()).toFloat()
                    if (pinchStart <= 0f) { pinchStart = d; pinchBase = curScale() } else setScale(pinchBase * d / pinchStart)
                } else if (e.pointerCount == 1 && dragOK) {
                    val nx = (e.x + dragDX).coerceIn(0f, width.toFloat()); val ny = (e.y + dragDY).coerceIn(0f, height.toFloat())
                    if (selAnalog) { ax = nx; ay = ny; knobX = nx; knobY = ny } else selBtn?.let { it.cx = nx; it.cy = ny }
                }
            }
            MotionEvent.ACTION_POINTER_UP -> { pinchStart = 0f; dragOK = false }
            MotionEvent.ACTION_UP, MotionEvent.ACTION_CANCEL -> { pinchStart = 0f; dragOK = false; saveAll() }
        }
        invalidate()
        return true
    }

    private fun toolbarAction(i: Int) {
        when (i) {
            0 -> if (selAnalog || selBtn != null) setScale(curScale() * 0.9f)
            1 -> if (selAnalog || selBtn != null) setScale(curScale() * 1.1f)
            2 -> { prefs.edit().clear().apply(); applyLayout() }
            3 -> { saveAll(); editMode = false; selBtn = null; selAnalog = false; onEditDone?.invoke() }
        }
        if (i < 2) saveAll()
        invalidate()
    }

    // ---------- jogo ----------
    override fun onTouchEvent(e: MotionEvent): Boolean {
        if (editMode) return editTouch(e)
        val act = e.actionMasked
        val upIdx = if (act == MotionEvent.ACTION_POINTER_UP) e.actionIndex else if (act == MotionEvent.ACTION_UP || act == MotionEvent.ACTION_CANCEL) -2 else -1
        val wasDown = btns.map { it.down }
        for (b in btns) b.down = false
        var foundAnalog = false
        var mask = 0
        for (i in 0 until e.pointerCount) {
            if (i == upIdx || upIdx == -2) continue
            val x = e.getX(i); val y = e.getY(i); val id = e.getPointerId(i)
            if (id == analogPtr || (analogPtr == -1 && Math.hypot((x - ax).toDouble(), (y - ay).toDouble()) <= ar * 1.25)) {
                analogPtr = id; foundAnalog = true
                var dx = x - ax; var dy = y - ay
                val lim = ar * 0.55f
                val dist = Math.hypot(dx.toDouble(), dy.toDouble()).toFloat()
                if (dist > lim) { dx *= lim / dist; dy *= lim / dist }
                knobX = ax + dx; knobY = ay + dy
                val t = lim * 0.45f
                if (dx < -t) mask = mask or (1 shl LEFT)
                if (dx > t) mask = mask or (1 shl RIGHT)
                if (dy < -t) mask = mask or (1 shl UP)
                if (dy > t) mask = mask or (1 shl DOWN)
                continue
            }
            for (b in btns) if (b.hit(x, y)) {
                b.down = true
                if (b.id < 100) mask = mask or (1 shl b.id)
            }
        }
        if (!foundAnalog) { analogPtr = -1; knobX = ax; knobY = ay }
        for ((i, b) in btns.withIndex()) if (b.down && !wasDown[i]) {
            performHapticFeedback(android.view.HapticFeedbackConstants.VIRTUAL_KEY)
            if (b.id == OPTION) onOption?.invoke()
            if (b.id == EXIT) onExit?.invoke()
        }
        Native.setInput(mask)
        invalidate()
        return true
    }

    fun clearInput() { for (b in btns) b.down = false; analogPtr = -1; knobX = ax; knobY = ay; Native.setInput(0); invalidate() }
}
