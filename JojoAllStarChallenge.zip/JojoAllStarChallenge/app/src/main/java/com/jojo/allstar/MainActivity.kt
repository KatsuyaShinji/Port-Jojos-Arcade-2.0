package com.jojo.allstar

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.net.Uri
import android.os.Bundle
import android.os.Process
import android.system.Os
import android.view.SurfaceHolder
import android.view.SurfaceView
import android.view.View
import android.view.WindowManager
import android.widget.FrameLayout
import android.widget.Toast
import java.io.File

class MainActivity : Activity(), SurfaceHolder.Callback {
    private lateinit var surface: SurfaceView
    private lateinit var overlay: OverlayView
    private lateinit var romsDir: File
    private lateinit var masterRom: File
    private var emuThread: Thread? = null
    @Volatile private var running = false
    @Volatile private var paused = true
    @Volatile private var surfaceReady = false
    @Volatile private var gameReady = false
    private var track: AudioTrack? = null
    private var starting = false

    // nomes possíveis do set no FBNeo (o core identifica o jogo pelo nome do zip)
    private val names = listOf("jojobane", "jojoba", "jojobaner1", "jojobanr1", "jojobar1", "jojobar", "jojobaj", "jojobajr1",
        "jojobau", "jojobaur1", "jojobaa", "jojobaan", "jojobanu", "jojobanj", "jojobaen", "jojobaenr1", "jojobajn", "jojobaun", "jojoban",
        "jojo", "jojor", "jojor1", "jojou", "jojoj", "jojon", "jojoa", "jojojr1")

    override fun onCreate(b: Bundle?) {
        super.onCreate(b)
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        romsDir = File(filesDir, "roms").apply { mkdirs() }
        masterRom = File(romsDir, "rom.zip")
        surface = SurfaceView(this)
        surface.holder.addCallback(this)
        overlay = OverlayView(this)
        overlay.onOption = { runOnUiThread { showMenu() } }
        overlay.onExit = { runOnUiThread { confirmExit() } }
        overlay.onEditDone = { runOnUiThread { paused = false; hideBars() } }
        val root = FrameLayout(this)
        root.addView(surface, FrameLayout.LayoutParams(-1, -1))
        root.addView(overlay, FrameLayout.LayoutParams(-1, -1))
        setContentView(root)
        hideBars()
    }

    private fun hideBars() {
        window.decorView.systemUiVisibility = (View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY or View.SYSTEM_UI_FLAG_FULLSCREEN or
                View.SYSTEM_UI_FLAG_HIDE_NAVIGATION or View.SYSTEM_UI_FLAG_LAYOUT_STABLE or
                View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN or View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION)
    }

    override fun onWindowFocusChanged(hasFocus: Boolean) { super.onWindowFocusChanged(hasFocus); if (hasFocus) hideBars() }

    override fun surfaceCreated(h: SurfaceHolder) {
        Native.setSurface(h.surface); surfaceReady = true
        if (!gameReady && !starting) {
            if (masterRom.exists() && masterRom.length() > 1_000_000) startEmu() else askRom(true)
        } else paused = false
    }
    override fun surfaceChanged(h: SurfaceHolder, f: Int, w: Int, hh: Int) {}
    override fun surfaceDestroyed(h: SurfaceHolder) { surfaceReady = false; paused = true; Native.setSurface(null) }

    override fun onPause() { super.onPause(); paused = true; overlay.clearInput(); track?.pause() }
    override fun onResume() { super.onResume(); if (gameReady && surfaceReady) { paused = false; track?.play() } }

    override fun onDestroy() {
        running = false
        try { emuThread?.join(1500) } catch (_: Exception) {}
        if (gameReady) { Native.unload(); gameReady = false }
        track?.release()
        super.onDestroy()
    }

    // ---------- importar ROM (só na primeira vez; depois fica guardada no app) ----------
    private fun askRom(first: Boolean) {
        AlertDialog.Builder(this).setTitle("ROM do jogo")
            .setMessage(if (first) "Escolha o arquivo .zip da ROM. Isso só é preciso uma vez: o app guarda uma cópia e você pode apagar o arquivo dos Downloads." else "Escolha o novo arquivo .zip da ROM.")
            .setCancelable(false)
            .setPositiveButton("Escolher") { _, _ ->
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT).apply { addCategory(Intent.CATEGORY_OPENABLE); type = "*/*" }
                startActivityForResult(i, 42)
            }
            .setNegativeButton("Sair") { _, _ -> finish() }.show()
    }

    @Deprecated("Deprecated in Java")
    override fun onActivityResult(req: Int, res: Int, data: Intent?) {
        super.onActivityResult(req, res, data)
        if (req != 42) return
        val uri: Uri? = data?.data
        if (res != RESULT_OK || uri == null) { askRom(!masterRom.exists()); return }
        Toast.makeText(this, "Copiando ROM...", Toast.LENGTH_SHORT).show()
        Thread {
            try {
                val tmp = File(romsDir, "rom.tmp")
                contentResolver.openInputStream(uri)!!.use { i -> tmp.outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                romsDir.listFiles()?.filter { it.name != "rom.tmp" }?.forEach { it.delete() }
                getSharedPreferences("p", MODE_PRIVATE).edit().clear().apply()
                tmp.renameTo(masterRom)
                gameReady = false
                runOnUiThread { if (surfaceReady) startEmu() }
            } catch (e: Exception) {
                runOnUiThread { Toast.makeText(this, "Erro ao copiar: ${e.message}", Toast.LENGTH_LONG).show(); askRom(true) }
            }
        }.start()
    }

    // ---------- emulação ----------
    private fun linkName(n: String) {
        val f = File(romsDir, "$n.zip")
        if (f.exists()) return
        try { Os.symlink(masterRom.absolutePath, f.absolutePath) } catch (_: Exception) { masterRom.copyTo(f, true) }
    }

    private fun startEmu() {
        if (starting) return
        starting = true; running = false
        try { emuThread?.join(1500) } catch (_: Exception) {}
        running = true; paused = true
        emuThread = Thread {
            Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_DISPLAY)
            val sys = File(filesDir, "system").apply { mkdirs() }
            val save = File(filesDir, "saves").apply { mkdirs(); File(this, "fbneo").mkdirs() }
            val core = File(applicationInfo.nativeLibraryDir, "libfbneo_libretro.so")
            Native.clearLog()
            if (!Native.loadCore(core.absolutePath, sys.absolutePath, save.absolutePath)) { fail("Não consegui carregar o core."); return@Thread }
            names.forEach { linkName(it) }
            val prefs = getSharedPreferences("p", MODE_PRIVATE)
            val order = listOfNotNull(prefs.getString("name", null)) + names
            var ok = false
            val tried = StringBuilder()
            runOnUiThread { Toast.makeText(this, "Identificando a ROM (só na primeira vez)...", Toast.LENGTH_LONG).show() }
            val dummy = ShortArray(16384)
            for (n in order.distinct()) {
                if (!running) return@Thread
                if (!Native.loadGame(File(romsDir, "$n.zip").absolutePath)) { tried.append("$n: recusado\n"); continue }
                Native.detect(true)
                repeat(4) { Native.runFrame(dummy) }
                val score = Native.errScore()
                Native.detect(false)
                if (score < 0) { prefs.edit().putString("name", n).apply(); ok = true; break }
                tried.append("$n: tela de erro ($score)\n")
                Native.unload()
            }
            if (!ok) { fail("Nenhum nome de set funcionou com essa ROM.", tried.toString()); return@Thread }
            val rate = Native.sampleRate()
            val min = AudioTrack.getMinBufferSize(rate, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT)
            track = AudioTrack.Builder()
                .setAudioAttributes(AudioAttributes.Builder().setUsage(AudioAttributes.USAGE_GAME).setContentType(AudioAttributes.CONTENT_TYPE_SONIFICATION).build())
                .setAudioFormat(AudioFormat.Builder().setSampleRate(rate).setEncoding(AudioFormat.ENCODING_PCM_16BIT).setChannelMask(AudioFormat.CHANNEL_OUT_STEREO).build())
                .setBufferSizeInBytes(min * 3).setTransferMode(AudioTrack.MODE_STREAM)
                .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY).build()
            track!!.play()
            gameReady = true; starting = false; paused = !surfaceReady
            val buf = ShortArray(16384)
            while (running) {
                if (paused) { Thread.sleep(30); continue }
                val t0 = System.nanoTime()
                val n = Native.runFrame(buf)
                if (n > 0) track!!.write(buf, 0, n * 2, AudioTrack.WRITE_BLOCKING)
                else { val dt = (System.nanoTime() - t0) / 1_000_000; if (dt < 16) Thread.sleep(16 - dt) }
            }
        }.also { it.start() }
    }

    private fun fail(msg: String, extra: String = "") {
        starting = false
        val log = extra + "\n" + Native.lastLog().takeLast(400)
        runOnUiThread {
            AlertDialog.Builder(this).setTitle("Erro").setMessage("$msg\n\n$log").setCancelable(false)
                .setPositiveButton("Escolher outra ROM") { _, _ -> askRom(false) }
                .setNegativeButton("Sair") { _, _ -> finish() }.show()
        }
    }

    // ---------- menus ----------
    private fun showMenu() {
        paused = true; overlay.clearInput()
        AlertDialog.Builder(this).setTitle("Jojo's All Star Challenge")
            .setItems(arrayOf("Continuar", "Reiniciar jogo", "Editar botões", "Trocar ROM", "Sair")) { _, w ->
                when (w) {
                    1 -> { Native.reset(); paused = false }
                    2 -> { paused = true; overlay.startEdit() }
                    3 -> { paused = true; askRom(false) }
                    4 -> finish()
                    else -> paused = false
                }
            }.setOnCancelListener { paused = false }.show()
    }

    private fun confirmExit() {
        paused = true; overlay.clearInput()
        AlertDialog.Builder(this).setMessage("Sair do jogo?")
            .setPositiveButton("Sair") { _, _ -> finish() }
            .setNegativeButton("Voltar") { _, _ -> paused = false }
            .setOnCancelListener { paused = false }.show()
    }
}
