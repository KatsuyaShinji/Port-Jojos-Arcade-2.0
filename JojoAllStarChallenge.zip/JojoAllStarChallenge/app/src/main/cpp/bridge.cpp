#include <jni.h>
#include <android/native_window_jni.h>
#include <android/log.h>
#include <dlfcn.h>
#include <string>
#include <mutex>
#include <atomic>
#include <cstring>
#include <cstdarg>
#include <cstdint>
#include <cstdio>

#define TAG "JojoBridge"
#define LOGI(...) __android_log_print(ANDROID_LOG_INFO, TAG, __VA_ARGS__)

struct retro_game_info { const char* path; const void* data; size_t size; const char* meta; };
struct retro_system_info { const char* library_name; const char* library_version; const char* valid_extensions; bool need_fullpath; bool block_extract; };
struct retro_game_geometry { unsigned base_width, base_height, max_width, max_height; float aspect_ratio; };
struct retro_system_timing { double fps; double sample_rate; };
struct retro_system_av_info { retro_game_geometry geometry; retro_system_timing timing; };
struct retro_log_callback { void (*log)(int level, const char* fmt, ...); };

typedef bool (*env_t)(unsigned, void*);
typedef void (*video_t)(const void*, unsigned, unsigned, size_t);
typedef void (*audio_t)(int16_t, int16_t);
typedef size_t (*audio_batch_t)(const int16_t*, size_t);
typedef void (*poll_t)();
typedef int16_t (*input_t)(unsigned, unsigned, unsigned, unsigned);

static void* g_lib = nullptr;
static void (*r_set_env)(env_t);
static void (*r_set_video)(video_t);
static void (*r_set_audio)(audio_t);
static void (*r_set_audio_batch)(audio_batch_t);
static void (*r_set_poll)(poll_t);
static void (*r_set_input)(input_t);
static void (*r_init)();
static void (*r_deinit)();
static void (*r_get_info)(retro_system_info*);
static void (*r_get_av)(retro_system_av_info*);
static bool (*r_load)(const retro_game_info*);
static void (*r_unload)();
static void (*r_run)();
static void (*r_reset)();

static std::string g_sys, g_save;
static std::mutex g_winMutex, g_logMutex;
static ANativeWindow* g_win = nullptr;
static int g_fmt = 1; // 1 = XRGB8888, 2 = RGB565
static unsigned g_curW = 0, g_curH = 0;
static std::atomic<uint32_t> g_buttons{0};
static std::string g_log;
static int16_t g_audio[16384];
static size_t g_audioFrames = 0;
static bool g_gameLoaded = false;
static double g_fps = 60.0, g_rate = 44100.0;
static std::atomic<bool> g_detect{false};
static std::atomic<int> g_errScore{-1};

static void core_log(int level, const char* fmt, ...) {
    char buf[1024];
    va_list ap; va_start(ap, fmt); vsnprintf(buf, sizeof(buf), fmt, ap); va_end(ap);
    __android_log_print(ANDROID_LOG_INFO, "FBNeo", "%s", buf);
    std::lock_guard<std::mutex> lk(g_logMutex);
    g_log += buf;
    if (g_log.size() > 3000) g_log.erase(0, g_log.size() - 3000);
}

static bool env_cb(unsigned cmd, void* data) {
    switch (cmd & 0xFFFF) {
        case 1: return true;                                   // SET_ROTATION
        case 3: *(bool*)data = true; return true;              // GET_CAN_DUPE
        case 6: return true;                                   // SET_MESSAGE
        case 8: return true;                                   // SET_PERFORMANCE_LEVEL
        case 9: *(const char**)data = g_sys.c_str(); return true;
        case 10: {                                             // SET_PIXEL_FORMAT
            int f = *(int*)data;
            if (f == 1 || f == 2) { g_fmt = f; return true; }
            return false;
        }
        case 11: return true;                                  // SET_INPUT_DESCRIPTORS
        case 16: return true;                                  // SET_VARIABLES
        case 18: return true;                                  // SET_SUPPORT_NO_GAME
        case 24: *(uint64_t*)data = (1ULL << 1); return true;  // INPUT_DEVICE_CAPABILITIES
        case 27: ((retro_log_callback*)data)->log = core_log; return true;
        case 30: *(const char**)data = g_sys.c_str(); return true;
        case 31: *(const char**)data = g_save.c_str(); return true;
        case 32: return true;                                  // SET_SYSTEM_AV_INFO
        case 35: return true;                                  // SET_CONTROLLER_INFO
        case 36: return true;                                  // SET_MEMORY_MAPS
        case 37: g_curW = 0; return true;                      // SET_GEOMETRY
        case 39: *(unsigned*)data = 0; return true;            // GET_LANGUAGE
        case 52: *(unsigned*)data = 0; return true;            // GET_CORE_OPTIONS_VERSION
        default: return false;
    }
}

static void video_cb(const void* data, unsigned w, unsigned h, size_t pitch) {
    if (!data) return;
    if (g_detect.load() && w > 8 && h > 8) {
        const uint8_t* sb = (const uint8_t*)data;
        auto px = [&](unsigned x, unsigned y, int& r, int& g, int& b) {
            if (g_fmt == 2) { uint16_t p = *(const uint16_t*)(sb + y * pitch + x * 2); r = ((p >> 11) & 31) << 3; g = ((p >> 5) & 63) << 2; b = (p & 31) << 3; }
            else { uint32_t p = *(const uint32_t*)(sb + y * pitch + x * 4); r = (p >> 16) & 255; g = (p >> 8) & 255; b = p & 255; }
        };
        int r, g, b; px(2, 2, r, g, b);
        bool blue = r < 70 && g < 70 && b > 170;
        px(w - 3, h - 3, r, g, b);
        bool light = r > 200 && g > 200 && b > 200;
        if (blue && light) {
            int dark = 0;
            for (unsigned y = 0; y < h; y += 2) for (unsigned x = 0; x < w; x += 2) {
                px(x, y, r, g, b);
                if ((r * 3 + g * 6 + b) / 10 < 110) dark++;
            }
            g_errScore.store(dark);
        } else g_errScore.store(-1);
    }
    std::lock_guard<std::mutex> lk(g_winMutex);
    if (!g_win) return;
    if (w != g_curW || h != g_curH) {
        ANativeWindow_setBuffersGeometry(g_win, w, h, g_fmt == 2 ? WINDOW_FORMAT_RGB_565 : WINDOW_FORMAT_RGBA_8888);
        g_curW = w; g_curH = h;
    }
    ANativeWindow_Buffer buf;
    if (ANativeWindow_lock(g_win, &buf, nullptr) < 0) return;
    const uint8_t* src = (const uint8_t*)data;
    if (g_fmt == 2) {
        for (unsigned y = 0; y < h && (int)y < buf.height; y++)
            memcpy((uint8_t*)buf.bits + (size_t)y * buf.stride * 2, src + y * pitch, w * 2);
    } else {
        for (unsigned y = 0; y < h && (int)y < buf.height; y++) {
            const uint32_t* s = (const uint32_t*)(src + y * pitch);
            uint32_t* d = (uint32_t*)buf.bits + (size_t)y * buf.stride;
            for (unsigned x = 0; x < w; x++) {
                uint32_t p = s[x];
                d[x] = 0xFF000000u | ((p & 0xFF) << 16) | (p & 0xFF00) | ((p >> 16) & 0xFF);
            }
        }
    }
    ANativeWindow_unlockAndPost(g_win);
}

static void audio_cb(int16_t l, int16_t r) {
    if (g_audioFrames < 8192) { g_audio[g_audioFrames * 2] = l; g_audio[g_audioFrames * 2 + 1] = r; g_audioFrames++; }
}
static size_t audio_batch_cb(const int16_t* d, size_t frames) {
    size_t n = frames; if (g_audioFrames + n > 8192) n = 8192 - g_audioFrames;
    memcpy(g_audio + g_audioFrames * 2, d, n * 4); g_audioFrames += n;
    return frames;
}
static void poll_cb() {}
static int16_t input_cb(unsigned port, unsigned device, unsigned index, unsigned id) {
    if (port != 0 || device != 1) return 0;
    uint32_t b = g_buttons.load();
    if (id == 256) return (int16_t)b;
    if (id < 16) return (b >> id) & 1;
    return 0;
}

#define SYM(var, name) var = (decltype(var))dlsym(g_lib, name); if (!var) { LOGI("sym faltando: %s", name); return JNI_FALSE; }

extern "C" {

JNIEXPORT jboolean JNICALL Java_com_jojo_allstar_Native_loadCore(JNIEnv* env, jobject, jstring jpath, jstring jsys, jstring jsave) {
    const char* p = env->GetStringUTFChars(jpath, nullptr);
    const char* s = env->GetStringUTFChars(jsys, nullptr);
    const char* v = env->GetStringUTFChars(jsave, nullptr);
    g_sys = s; g_save = v;
    g_lib = dlopen(p, RTLD_NOW);
    if (!g_lib) { std::lock_guard<std::mutex> lk(g_logMutex); g_log += std::string("dlopen falhou: ") + dlerror() + "\n"; }
    env->ReleaseStringUTFChars(jpath, p); env->ReleaseStringUTFChars(jsys, s); env->ReleaseStringUTFChars(jsave, v);
    if (!g_lib) return JNI_FALSE;
    SYM(r_set_env, "retro_set_environment"); SYM(r_set_video, "retro_set_video_refresh");
    SYM(r_set_audio, "retro_set_audio_sample"); SYM(r_set_audio_batch, "retro_set_audio_sample_batch");
    SYM(r_set_poll, "retro_set_input_poll"); SYM(r_set_input, "retro_set_input_state");
    SYM(r_init, "retro_init"); SYM(r_deinit, "retro_deinit"); SYM(r_get_info, "retro_get_system_info");
    SYM(r_get_av, "retro_get_system_av_info"); SYM(r_load, "retro_load_game"); SYM(r_unload, "retro_unload_game");
    SYM(r_run, "retro_run"); SYM(r_reset, "retro_reset");
    r_set_env(env_cb);
    r_init();
    r_set_video(video_cb); r_set_audio(audio_cb); r_set_audio_batch(audio_batch_cb);
    r_set_poll(poll_cb); r_set_input(input_cb);
    return JNI_TRUE;
}

JNIEXPORT jboolean JNICALL Java_com_jojo_allstar_Native_loadGame(JNIEnv* env, jobject, jstring jpath) {
    const char* p = env->GetStringUTFChars(jpath, nullptr);
    std::string path = p; env->ReleaseStringUTFChars(jpath, p);
    retro_game_info gi = { path.c_str(), nullptr, 0, nullptr };
    g_curW = 0; g_curH = 0;
    bool ok = r_load(&gi);
    if (ok) {
        retro_system_av_info av; memset(&av, 0, sizeof(av)); r_get_av(&av);
        g_fps = av.timing.fps > 1 ? av.timing.fps : 60.0;
        g_rate = av.timing.sample_rate > 8000 ? av.timing.sample_rate : 44100.0;
        g_gameLoaded = true;
    }
    return ok ? JNI_TRUE : JNI_FALSE;
}

JNIEXPORT void JNICALL Java_com_jojo_allstar_Native_detect(JNIEnv*, jobject, jboolean on) { g_errScore.store(-1); g_detect.store(on == JNI_TRUE); }
JNIEXPORT jint JNICALL Java_com_jojo_allstar_Native_errScore(JNIEnv*, jobject) { return g_errScore.load(); }

JNIEXPORT jint JNICALL Java_com_jojo_allstar_Native_sampleRate(JNIEnv*, jobject) { return (jint)(g_rate + 0.5); }

JNIEXPORT void JNICALL Java_com_jojo_allstar_Native_setSurface(JNIEnv* env, jobject, jobject surface) {
    std::lock_guard<std::mutex> lk(g_winMutex);
    if (g_win) { ANativeWindow_release(g_win); g_win = nullptr; }
    if (surface) g_win = ANativeWindow_fromSurface(env, surface);
    g_curW = 0; g_curH = 0;
}

JNIEXPORT void JNICALL Java_com_jojo_allstar_Native_setInput(JNIEnv*, jobject, jint mask) { g_buttons.store((uint32_t)mask); }

JNIEXPORT jint JNICALL Java_com_jojo_allstar_Native_runFrame(JNIEnv* env, jobject, jshortArray out) {
    if (!g_gameLoaded) return 0;
    g_audioFrames = 0;
    r_run();
    jsize cap = env->GetArrayLength(out) / 2;
    size_t n = g_audioFrames < (size_t)cap ? g_audioFrames : (size_t)cap;
    if (n) env->SetShortArrayRegion(out, 0, (jsize)(n * 2), g_audio);
    return (jint)n;
}

JNIEXPORT void JNICALL Java_com_jojo_allstar_Native_reset(JNIEnv*, jobject) { if (g_gameLoaded) r_reset(); }

JNIEXPORT void JNICALL Java_com_jojo_allstar_Native_unload(JNIEnv*, jobject) {
    if (g_gameLoaded) { r_unload(); g_gameLoaded = false; }
}

JNIEXPORT jstring JNICALL Java_com_jojo_allstar_Native_lastLog(JNIEnv* env, jobject) {
    std::lock_guard<std::mutex> lk(g_logMutex);
    return env->NewStringUTF(g_log.c_str());
}

JNIEXPORT void JNICALL Java_com_jojo_allstar_Native_clearLog(JNIEnv*, jobject) {
    std::lock_guard<std::mutex> lk(g_logMutex); g_log.clear();
}

}
